classdef APloss < dagnn.Loss
    properties
        opt
    end
    
    properties (Transient)
        Xp
        Xn
        norms
        Phi
        Dist
        histW
        histC
        c
        cp
        cn
        C
        Cp
        Cn
        numer
        denom
        aff_aux
    end

    methods
        function obj = APloss(varargin)
            obj.load(varargin{:});
        end

        function outputs = forward(obj, inputs, params)
            % forward pass
            Y = inputs{2}; % NxnL
            X = squeeze(inputs{1});  % 1x1xBxN -> BxN, logits for each bit
            [nbits, N] = size(X); assert(size(Y, 1) == N); 

            opts  = obj.opt;
            onGPU = numel(opts.gpus) > 0;

            % get aff
            if isempty(obj.aff_aux)
                Aff = affinity_binary(Y, []);
            else
                Aff = affinity_binary(Y, [], obj.aff_aux);
            end
            Xp = (Aff > 0); 
            Xn = (Aff < 0);
            if onGPU, Xp = gpuArray(Xp); Xn = gpuArray(Xn); end

            % compute distances from hash codes
            norms = sqrt(sum(X.^2, 1));  % 1xN
            Phi   = bsxfun(@rdivide, X, norms);
            Dist  = max(0,  2 - 2 * phi' * phi);  % because the norms are 1 now

            % estimate discrete histograms
            histW = 4 / opts.nbins;
            histC = 0 : histW : 4;
            L  = length(histC); 
            c  = zeros(N, L);   % distance histogram (continuous relaxation)
            cp = zeros(N, L);   % positive histogram (continuous relaxation)
            cn = zeros(N, L);   % negative histogram (continuous relaxation)
            if onGPU
                c  = gpuArray(c);
                cp = gpuArray(cp);
                cn = gpuArray(cn);
            end

            % triangular pulse / linear interpolation
            for l = 1:L
                pulse = triPulse(Dist, histC(l), histW);  % NxN
                cp(:, l) = sum(pulse .* Xp, 2);
                cn(:, l) = sum(pulse .* Xn, 2);
            end
            c  = cp + cn;
            C  = cumsum(c, 2);  % cumulative histogram (continuous relaxation)
            Cp = cumsum(cp, 2);
            Cn = cumsum(cn, 2);

            % common variables to reuse
            C_1d  = circshift(C , 1, 2);  C_1d (:, 1) = 0;   % C_{d-1}
            Cp_1d = circshift(Cp, 1, 2);  Cp_1d(:, 1) = 0;   % C_{d-1}^+
            Cn_1d = circshift(Cn, 1, 2);  Cn_1d(:, 1) = 0;   % C_{d-1}^-
            numer = Cp_1d + Cp + 1;
            denom = C_1d  + C  + 1;

            % compute simplified APr
            APr_s = cp .* numer ./ denom;
            APr_s = sum(APr_s, 2) ./ sum(Xp, 2);
            ind = ~isnan(fastap) & ~isinf(fastap);
            obj.numAveraged = gather(sum(ind));
            obj.average = gather(mean(APr_s(ind)));

            % output
            outputs{1} = mean(APr_s(ind)) * N;
            obj.Xp    = Xp   ;
            obj.Xn    = Xn   ;
            obj.norms = norms;
            obj.Phi   = Phi  ;
            obj.Dist  = Dist ;
            obj.histW = histW;
            obj.histC = histC;
            obj.cp    = cp   ;
            obj.cn    = cn   ;
            obj.c     = c    ;
            obj.Cp    = Cp   ;
            obj.Cn    = Cn   ;
            obj.C     = C    ;
            obj.numer = numer;
            obj.denom = denom;
        end

        function [dInputs, dParams] = backward(obj, inputs, params, dOutputs)
            % backward pass
            nbits = size(inputs{1}, 3);
            N     = size(inputs{1}, 4);
            opts  = obj.opt;
            onGPU = numel(opts.gpus) > 0;
            Xp    = obj.Xp   ; 
            Xn    = obj.Xn   ; 
            norms = obj.norms;
            Phi   = obj.Phi  ; 
            Dist  = obj.Dist ; 
            histW = obj.histW; 
            histC = obj.histC; 
            c     = obj.c    ; 
            cp    = obj.cp   ; 
            cn    = obj.cn   ; 
            C     = obj.C    ; 
            Cp    = obj.Cp   ; 
            Cn    = obj.Cn   ; 
            numer = obj.numer; 
            denom = obj.denom; 
            L     = length(histC);

            % 1. d(APr_s)/d(c+) in matrix form
            % diagonal terms
            d_AP_cp_dia = (2*Cp+1)./denom - cp.*numer./(denom.^2);
            % off-diagonal terms
            d_AP_cp_off = cp .* (denom - numer) ./ denom2;
            % combine
            d_AP_cp = d_AP_cp_dia + d_AP_cp_off * triu(ones(L), 1)'; 
            % normalize
            d_AP_cp = bsxfun(@rdivide, d_AP_cp, sum(Xp, 2));
            d_AP_cp(isnan(d_AP_cp)|isinf(d_AP_cp)) = 0;

            % 2. d(APr_s)/d(c-)
            % diagonal & off-diagonal terms (are the same)
            d_AP_cn = -cp .* numer ./ (denom.^2);
            % combine
            d_AP_cn = d_AP_cn * triu(ones(L))';
            % normalize
            d_AP_cn = bsxfun(@rdivide, d_AP_cn, sum(Xp, 2));
            d_AP_cn(isnan(d_AP_cn)|isinf(d_AP_cn)) = 0;

            % 3. d(APr_s)/d(Phi)
            % advancing the chain rule with differentiable histogram binning
            d_AP_Phi = zeros(nbits, N);
            if onGPU
                d_AP_Phi = gpuArray(d_AP_Phi); 
            end
            for l = 1:L
                % NxN matrix of delta'(i, j, l) for fixed l
                dpulse = dTriPulse(Dist, histC(l), histW);  % NxN
                ddp = dpulse .* Xp;
                ddn = dpulse .* Xn;

                % A*B + B*A
                alpha_p = diag(d_AP_cp(:, l));  
                alpha_n = diag(d_AP_cn(:, l));  
                Ap = ddp * alpha_p + alpha_p * ddp;
                An = ddn * alpha_n + alpha_n * ddn;

                % accumulate gradient
                d_AP_Phi = d_AP_Phi - 0.5 * Phi * (Ap + An);
            end

            % 4. d(AP)/d(x)
            % backprop through L2 normalization
            %
            % followed derivations from: 
            % http://freesouls.github.io/2015/08/30/caffe-implement-l2-normlization-layer/
            %
            d_AP_Phi = -d_AP_Phi;  % because we maximize AP
            scaling  = diag(d_AP_Phi' * Phi);  % right mult: scale the cols
            d_Phi_x  = d_AP_Phi - Phi * diag(scaling);
            d_AP_x   = bsxfun(@rdivide, d_Phi_x, norms);

            % output
            dInputs{1} = zeros(size(inputs{1}), 'single');
            if onGPU, dInputs{1} = gpuArray(dInputs{1}); end
            dInputs{1}(1, 1, :, :) = single(d_AP_x);
            dInputs{2} = [];
            dParams = {};
        end
    end
end
